﻿namespace UnitTesting
{
    using System;
    using System.Linq;
    using Contracts;
    using Dummies;
    using NUnit.Framework;

    [TestFixture]
    public class GenericsTests
    {

        #region Övning 1

        [Test]
        public void CanCreateGenericClass() {
            // TestDelegate är bara en konstruktion för att arbeta med vissa speciella tester - fundera inte över det!
            TestDelegate createMyGenericClass = () => { var yourImplementation = new MyGenericClass<Object>(); };

            Assert.DoesNotThrow(createMyGenericClass);
        }

        #endregion

        #region Övning 2

        //[Test]
        //public void CanCallGetResult() {
        //    TestDelegate callGetResult = () => {
        //        var yourImplementation = new MyGenericClass<Object>();
        //        yourImplementation.GetResult();
        //    };

        //    Assert.DoesNotThrow(callGetResult);
        //}

        #endregion

        #region Övning 3

        //// Det här testet körs flera gånger, en gång för varje TestCase nedan. Argumenten kopplas som parametrar till testmetoden.
        //[TestCase(typeof (MyGenericClass<String>), typeof (String))]
        //[TestCase(typeof (MyGenericClass<Boolean>), typeof (Boolean))]
        //public void WithTypeParameterForClass_GetResult_ReturnsSameType(Type yourType, Type expectedReturnType)
        //{
        //    var yourGetResult = yourType?.GetMethod("GetResult");
        //    var yourReturnType = yourGetResult?.ReturnType;

        //    Assert.That(yourReturnType, Is.EqualTo(expectedReturnType));
        //}

        #endregion

        #region Övning 4

        //[Test]
        //public void Assert_ConstrainedMethodParameter_IsConstrainedToBaseClass()
        //{
        //    var yourImplementation = new MyGenericClass<String>();
        //    var yourMethod =
        //        yourImplementation.GetType()
        //            .GetMethod("ConstrainedMethod");

        //    Assert.That(yourMethod, Is.Not.Null,
        //        "Du måste implementera en metod som heter 'ConstrainedMethod' på din MyGenericClass.");

        //    var constraintType = yourMethod?
        //            .GetGenericArguments()
        //            .FirstOrDefault()?
        //            .GetGenericParameterConstraints()
        //            .FirstOrDefault()?
        //            .UnderlyingSystemType;

        //    Assert.That(constraintType, Is.EqualTo(typeof (BaseClass)),
        //        "Du måste se till att din 'ConstrainedMethod' tar minst en parameter begränsad (constrained) till BaseClass.");
        //}

        #endregion

        #region Övning 5

        //[Test]
        //public void WithoutParameter_CanCallConstrainedMethod()
        //{
        //    var yourImplementation = new MyGenericClass<Int32>();
        //    TestDelegate callConstrainedMethod = () =>
        //    {
        //        yourImplementation.ConstrainedMethod<BaseClass>();
        //    };

        //    Assert.DoesNotThrow(callConstrainedMethod);
        //}

        #endregion

        #region Övning 6

        //[Test]
        //public void WithFullfilledConstraints_CanCallConstrainedMethod() {
        //    var yourImplementation = new MyGenericClass<String>();

        //    TestDelegate callConstrainedMethod = () => {
        //        var appropriateObject = new DummyOne();
        //        yourImplementation.ConstrainedMethod(appropriateObject);
        //    };

        //    Assert.DoesNotThrow(callConstrainedMethod);
        //}

        #endregion

        #region Övning 7

        //[Test]
        //public void WithFullfilledConstraints_CallOtherConstrainedMethod_ShouldBeCalledMethodIsCalled() {
        //    var yourImplementation = new MyGenericClass<String>();

        //    // InterfaceImplementationDummy nedan är en klass som hjälper testet att verifiera hur du implementerat
        //    // metoden 'OtherConstrainedMethod'. Titta på den så förstår du mer.
        //    var appropriateObject = new InterfaceImplementationDummy();
        //    yourImplementation.OtherConstrainedMethod(appropriateObject);

        //    Assert.That(appropriateObject.MandatoryMethodWasCalled, Is.True);
        //}

        #endregion

        #region Övning 8

        //[Test]
        //public void SoYouPassedExcercise7_ButDidYouActuallyUseGenerics()
        //{
        //    var yourImplementation = new MyGenericClass<String>();

        //    var yourMethod =
        //        yourImplementation.GetType()
        //            .GetMethod("OtherConstrainedMethod");

        //    var constraintType = yourMethod?
        //        .GetGenericArguments()
        //        .FirstOrDefault()?
        //        .GetGenericParameterConstraints()
        //        .FirstOrDefault()?
        //        .UnderlyingSystemType;

        //    Assert.That(constraintType, Is.EqualTo(typeof(IConstraintInterface)),
        //        "Tydligen inte - gör om, gör rätt ;)");
        //}

        #endregion

    }
}