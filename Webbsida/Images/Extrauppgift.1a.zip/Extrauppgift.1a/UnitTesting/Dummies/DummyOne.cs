﻿namespace UnitTesting.Dummies
{
    using Contracts;

    internal class DummyOne : BaseClass
    {
    }
}