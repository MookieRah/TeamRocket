﻿namespace Contracts
{
    using System;

    public class InterfaceImplementationDummy : IConstraintInterface
    {
        public Boolean MandatoryMethodWasCalled { get; private set; }

        public void ShouldBeCalled()
        {
            MandatoryMethodWasCalled = true;
        }
    }

    public interface IConstraintInterface
    {
        void ShouldBeCalled();
    }
}