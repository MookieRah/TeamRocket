﻿namespace Contracts
{
    public abstract class BaseClass
    {
    }
}